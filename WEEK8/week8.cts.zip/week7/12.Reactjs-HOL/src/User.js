import React from 'react';

function User() {
  return (
    <div>
      <h2>Welcome, User!</h2>
      <p>You are logged in. You can now book your flight tickets.</p>
      <button>Book Chennai → Delhi</button><br /><br />
      <button>Book Mumbai → Bangalore</button><br /><br />
      <button>Book Kolkata → Hyderabad</button>
    </div>
  );
}

export default User;
