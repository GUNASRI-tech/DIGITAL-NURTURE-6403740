import React from 'react';

function BlogDetails() {
  return (
    <div>
      <h3>Blog Details</h3>
      <p>Blog Title: "Digital Nuture 4.0 tracker"</p>
      <p>Currently in week 7</p>
      <p>Learnings: ReactJs</p>
    </div>
  );
}

export default BlogDetails;
